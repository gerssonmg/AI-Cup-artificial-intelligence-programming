from enum import IntEnum

class TextAlignment(IntEnum):
    LEFT = 0
    CENTER = 1
    RIGHT = 2
